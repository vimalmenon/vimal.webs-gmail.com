import * as React from "react";
import {
  Link,
  withRouter
} from "react-router-dom";

class Dashboard extends React.Component {
    
    render () {
        return (
            <section class="dashboard d-flex flex-column h-100">
                <header class="header p-2">
                    <span class="d-flex flex-row-reverse">
                        <i class="fa fa-user-circle mx-2" aria-hidden="true" />
                        <i class="fa fa-envelope mx-2" aria-hidden="true" />
                        <i class="fa fa-bell mx-2" aria-hidden="true" />
                    </span>
                </header>
                <section class="d-flex content flex-fill flex-wrap">
                    <aside class="sidebar p-2 d-flex flex-column h-100">
                        <ul class="flex-fill p-3">
                            <li class="my-4">
                                <span class="active" />
                                <i class="fa fa-home mx-3" aria-hidden="true" />
                                Home
                            </li>
                            <li class="my-4">
                                <i class="fa fa-balance-scale mx-3" aria-hidden="true" />
                                View balances
                            </li>
                            <li class="my-4">
                                <i class="fa fa-cc-amex mx-3" aria-hidden="true" />
                                Make a payment
                            </li>
                            <li class="my-4">
                                <i class="fa fa-exchange mx-3" aria-hidden="true" />
                                Make a transfer
                            </li>
                            <li class="my-4">
                                <i class="fa fa-unlock-alt mx-3" aria-hidden="true" />
                                Manage deposits
                            </li>
                            <li class="my-4">
                                <i class="fa fa-book mx-3" aria-hidden="true" />
                                Manage reports
                            </li>
                            <li class="my-4">
                                <i class="fa fa-user-o mx-3" aria-hidden="true" />
                                Manager users
                            </li>
                            <li class="my-4">
                                <i class="fa fa-address-card mx-3" aria-hidden="true" />
                                Manage cards
                            </li>
                            <li class="my-4">
                                <i class="fa fa-bar-chart mx-3" aria-hidden="true" />
                                View insights
                            </li>
                            <li class="my-4">
                                <i class="fa fa-plug mx-3" aria-hidden="true" />
                                Integrate with a 3rd party
                            </li>
                        </ul>
                        <ul class="h-30 p-3">
                            <li class="my-4">
                                <i class="fa fa-life-ring mx-3" aria-hidden="true" />
                                Support
                            </li>
                            <li class="my-4">
                                <i class="fa fa-sign-out mx-3" aria-hidden="true" />
                                Logout
                            </li>
                        </ul>
                    </aside>
                    <section class="main flex-fill">
                        <div class="main-box h-100 p-3" style={{"overflow": "auto"}}>
                            <div class="row">
                                <div class="col-sm-12">
                                    <h3 class="h3 my-3">Dashboard</h3>
                                    {/*<button onClick={() => {this.props.history.push("/register/business/onboarding")}}>move</button>*/}
                                </div>
                                <div class="col-sm-12">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="row">
                                                5 Currency balances
                                            </div>
                                            <div class="row">
                                                3 Live deposits
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    Currency breakdown
                                                </div>
                                                 <div class="col-sm-12">
                                                    <div class="card my-3">
                                                        <div class="card-body">
                                                            <p class="card-text">
                                                                Some quick example text to build on the card title and make up the bulk of the card's content.
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    Recent transaction
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="card my-1">
                                                        <div class="card-body">
                                                            <p class="card-text">
                                                                Some quick example text to build on the card title and make up the bulk of the card's content.
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="card my-1">
                                                        <div class="card-body">
                                                            <p class="card-text">
                                                                Some quick example text to build on the card title and make up the bulk of the card's content.
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="card my-1">
                                                        <div class="card-body">
                                                            <p class="card-text">
                                                                vimal menon
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="card my-1">
                                                        <div class="card-body">
                                                            <p class="card-text">
                                                                Some quick example text to build on the card title and make up the bulk of the card's content.
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="card my-1">
                                                        <div class="card-body">
                                                            <h5 class="card-title d-flex justify-content-between">
                                                                <span class="h5">Special title treatment</span>
                                                                <i class="fa fa-ellipsis-v" aria-hidden="true" />
                                                            </h5>
                                                            <div class="card-text">
                                                                this is text
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </section>
            </section>
        );
    }
    componentDidMount () {
        let body = document.querySelector("body");
        let main = document.querySelector("#main");
        body.classList.add("overflow-hidden");
        main.classList.add("full-height");
    }
    componentWillUnmount () {
        let body = document.querySelector("body");
        let main = document.querySelector("#main");
        body.classList.remove("overflow-hidden");
        main.classList.remove("full-height");
    }
}

export default withRouter(Dashboard);